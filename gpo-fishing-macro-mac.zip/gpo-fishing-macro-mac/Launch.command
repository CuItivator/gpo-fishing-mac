#!/bin/bash
cd "$(dirname "$0")"
source src/find_python.sh || { read -n 1 -s -r -p "  press any key to close"; exit 1; }
"$PY" src/bootstrap.py main.py
