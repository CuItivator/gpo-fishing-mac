import numpy as np

import digits


PROMPT_TEXT = (0.377, 0.751, 0.622, 0.778)
MAX_TEXT = (0.503, 0.748, 0.560, 0.781)
YES_BTN = (0.418, 0.906)
COUNT_BOX = (0.500, 0.906)
NO_BTN = (0.581, 0.906)
YES_TEXT = (0.385, 0.891, 0.451, 0.922)
PANEL_BODY = (0.380, 0.800, 0.620, 0.880)
STORE_BTN = (0.450, 0.785, 0.550, 0.815)
STORE_CLICK = (0.500, 0.800)
BACKPACK_DROP = (0.410, 0.710)
BACKPACK_HEADER = (0.320, 0.300, 0.412, 0.340)

YES_WHITE = 0.015
PROMPT_WHITE = 0.0117
MAX_YELLOW = 0.022
MAX_YELLOW_NONE = 0.0055
STORE_GREEN = 0.08
HEADER_WHITE = 0.017

PANEL_IN_TOP = (0.395, 0.7435, 0.603, 0.7633)
PANEL_OUT_TOP = (0.395, 0.7019, 0.603, 0.7197)
PANEL_IN_LEFT = (0.374, 0.771, 0.392, 0.850)
PANEL_OUT_LEFT = (0.343, 0.771, 0.361, 0.850)

HOTBAR_H = 0.06
SLOT_FRAC = 0.95
SLOT_GAP = 0.0088
SLOT_TOP = 0.9315
LABEL_FRAC = 0.3
LABEL_WHITE = 0.03
MAX_SLOTS = 10

BAIT_TITLE = (0.435, 0.69, 0.565, 0.718)
TITLE_WHITE = 0.025
BAIT_X0 = 0.435
BAIT_X1 = 0.565
BAIT_LIST_TOP = 0.725
BAIT_ROW_H = 0.0306
BAIT_ROW_GAP = 5
BAIT_NAME_X = (0.4447, 0.536)
BAIT_COUNT_X = (0.5422, 0.5617)
BAIT_ROWS_MAX = 6
RING_PX = 5
COUNT_ORANGE = 0.04
NAME_WHITE = 0.08
NAME_CYAN = 0.05
NAME_MAGENTA = 0.01
RING_WARM = 0.12
KINDS = ("legendary", "rare", "common")
KIND_NAMES = {"legendary": "Legendary Fish Bait", "rare": "Rare Fish Bait", "common": "Common Fish Bait"}


def white(img):
    return (img >= 225).all(axis=2)


def yellow(img):
    c = img.astype(int)
    b, g, r = c[..., 0], c[..., 1], c[..., 2]
    return (r > 200) & (g > 170) & (b < 120)


def green(img):
    c = img.astype(int)
    b, g, r = c[..., 0], c[..., 1], c[..., 2]
    return (g > 100) & (r < 90) & (b < 60)


def orange(img):
    c = img.astype(int)
    b, g, r = c[..., 0], c[..., 1], c[..., 2]
    return (r > 200) & (g > 120) & (g < 200) & (b < 70)


def cyan(img):
    c = img.astype(int)
    b, g, r = c[..., 0], c[..., 1], c[..., 2]
    return (b >= 190) & (g >= 190) & (r <= 205) & (r >= 60)


def magenta(img):
    c = img.astype(int)
    b, g, r = c[..., 0], c[..., 1], c[..., 2]
    return (r > 150) & (b > 150) & (g < 140)


def warm(img):
    c = img.astype(int)
    b, g, r = c[..., 0], c[..., 1], c[..., 2]
    return (r > 150) & (g > 60) & (b < 80) & (r - b > 100)


def frac(img, mask):
    return float(mask(img).mean()) if img.size else 0.0


class BaitRow(object):
    def __init__(self, index, kind, count, selected, centre, ring):
        self.index = index
        self.kind = kind
        self.count = count
        self.selected = selected
        self.centre = centre
        self.ring = ring

    @property
    def name(self):
        return KIND_NAMES.get(self.kind, self.kind)


class View(object):
    def __init__(self, screen):
        self.screen = screen
        self.img, _ = screen.grab()
        self.s = screen.scale
        self.cx, self.cy, self.cw, self.ch = screen.client()

    def pt(self, f):
        return int(round(self.cx + f[0] * self.cw)), int(round(self.cy + f[1] * self.ch))

    def region(self, f):
        x0, y0 = self.pt(f[:2])
        x1, y1 = self.pt(f[2:])
        return self._slice(x0, y0, x1, y1)

    def _slice(self, x0, y0, x1, y1):
        s = self.s
        x0, y0, x1, y1 = [int(round(v * s)) for v in (x0, y0, x1, y1)]
        h, w = self.img.shape[:2]
        x0, x1 = max(0, min(w, x0)), max(0, min(w, x1))
        y0, y1 = max(0, min(h, y0)), max(0, min(h, y1))
        return self.img[y0:y1, x0:x1]

    def count(self, f, mask):
        r = self.region(f)
        return int(mask(r).sum()) if r.size else 0

    def frac(self, f, mask):
        return frac(self.region(f), mask)

    def slot_size(self):
        return SLOT_FRAC * HOTBAR_H * self.ch

    def slot_x(self, i, n):
        slot = self.slot_size()
        gap = SLOT_GAP * self.cw
        total = n * slot + (n - 1) * gap
        return self.cx + self.cw / 2.0 - total / 2.0 + i * (slot + gap)

    def slot_top(self):
        return self.cy + SLOT_TOP * self.ch

    def slot_centre(self, i, n):
        slot = self.slot_size()
        return int(round(self.slot_x(i, n) + slot / 2.0)), int(round(self.slot_top() + slot / 2.0))

    def _label_white(self, i, n):
        slot = self.slot_size()
        lab = LABEL_FRAC * slot
        x = self.slot_x(i, n) + slot / 2.0 - lab / 2.0
        y = self.slot_top() - lab / 2.0
        return frac(self._slice(x, y, x + lab, y + lab), white)

    def hotbar_slots(self):
        best = 0
        for n in range(1, MAX_SLOTS + 1):
            if all(self._label_white(i, n) >= LABEL_WHITE for i in range(n)):
                best = n
        return best

    def bait_row_box(self, i):
        y0 = self.cy + BAIT_LIST_TOP * self.ch + i * (BAIT_ROW_H * self.ch + BAIT_ROW_GAP)
        y1 = y0 + BAIT_ROW_H * self.ch
        return self.cx + BAIT_X0 * self.cw, y0, self.cx + BAIT_X1 * self.cw, y1

    def _ring_warm(self, x0, y0, x1, y1):
        p = RING_PX
        parts = [self._slice(x0 - p, y0 - p, x1 + p, y0), self._slice(x0 - p, y1, x1 + p, y1 + p),
                 self._slice(x0 - p, y0, x0, y1), self._slice(x1, y0, x1 + p, y1)]
        total = sum(r.shape[0] * r.shape[1] for r in parts)
        if total == 0:
            return 0.0
        return sum(int(warm(r).sum()) for r in parts if r.size) / float(total)

    def bait_rows(self):
        rows = []
        for i in range(BAIT_ROWS_MAX):
            x0, y0, x1, y1 = self.bait_row_box(i)
            name = self._slice(self.cx + BAIT_NAME_X[0] * self.cw, y0, self.cx + BAIT_NAME_X[1] * self.cw, y1)
            cnt = self._slice(self.cx + BAIT_COUNT_X[0] * self.cw, y0, self.cx + BAIT_COUNT_X[1] * self.cw, y1)
            if not name.size or not cnt.size or frac(cnt, orange) < COUNT_ORANGE:
                break
            if frac(name, white) >= NAME_WHITE:
                kind = "common"
            elif frac(name, cyan) >= NAME_CYAN:
                kind = "rare"
            elif frac(name, magenta) >= NAME_MAGENTA:
                kind = "legendary"
            else:
                break
            count, _text = digits.read_number(orange(cnt))
            centre = (int(round((x0 + x1) / 2.0)), int(round((y0 + y1) / 2.0)))
            rows.append(BaitRow(i, kind, count, False, centre, self._ring_warm(x0, y0, x1, y1)))
        if rows:
            best = max(rows, key=lambda r: r.ring)
            if best.ring >= RING_WARM:
                best.selected = True
        return rows


def prompt_open(v):
    return v.frac(YES_TEXT, white) >= YES_WHITE and v.frac(PROMPT_TEXT, white) >= PROMPT_WHITE \
        and v.frac(MAX_TEXT, yellow) < MAX_YELLOW_NONE


def amount_open(v):
    return v.frac(MAX_TEXT, yellow) >= MAX_YELLOW


def store_button(v):
    return v.frac(STORE_BTN, green) >= STORE_GREEN


def backpack_open(v):
    return v.hotbar_slots() == MAX_SLOTS or v.frac(BACKPACK_HEADER, white) >= HEADER_WHITE


def dialog_panel(v):
    def mean(f):
        r = v.region(f)
        return float(r.mean()) if r.size else 0.0
    top = mean(PANEL_IN_TOP) / max(1.0, mean(PANEL_OUT_TOP))
    left = mean(PANEL_IN_LEFT) / max(1.0, mean(PANEL_OUT_LEFT))
    return top < 0.8 and left < 0.8


def rod_equipped(v):
    return v.frac(BAIT_TITLE, white) >= TITLE_WHITE or bool(v.bait_rows())


def read_max(v):
    return digits.read_number(yellow(v.region(MAX_TEXT)), after_gap=True)


def bait_row(v, kind):
    for r in v.bait_rows():
        if r.kind == kind:
            return r
    return None


def selected_bait(v):
    for r in v.bait_rows():
        if r.selected:
            return r
    return None


def read_bait(v, kind="common"):
    r = bait_row(v, kind)
    return None if r is None else r.count
