import time

import ui
from core import inputs

CHOICES = ("common", "rare", "legendary", "best")


def choose(rows, want):
    order = list(ui.KINDS) if want == "best" else [want]
    if "common" not in order:
        order.append("common")
    for kind in order:
        for r in rows:
            if r.kind == kind and (r.count is None or r.count > 0):
                return r
    return None


def ensure_bait(screen, cfg, log, stop=lambda: False):
    want = str(cfg.get("bait", "common"))
    if want not in CHOICES:
        want = "common"
    v = ui.View(screen)
    rows = v.bait_rows()
    if not rows:
        return None, False
    target = choose(rows, want)
    if target is None:
        return None, False
    if target.selected:
        return target, False
    log("bait: switching to %s" % target.name)
    inputs.click(*target.centre)
    t0 = time.perf_counter()
    while time.perf_counter() - t0 < 2.0 and not stop():
        time.sleep(0.15)
        row = ui.bait_row(ui.View(screen), target.kind)
        if row is not None and row.selected:
            log("bait: using %s%s" % (row.name, "" if row.count is None else " (x%d)" % row.count))
            return row, True
    log("bait: could not select %s" % target.name)
    return target, True
