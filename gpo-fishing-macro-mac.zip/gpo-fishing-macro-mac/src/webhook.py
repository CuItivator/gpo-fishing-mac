import copy
import json
import ssl
import threading
import urllib.error
import urllib.parse
import urllib.request
import uuid
from datetime import datetime, timezone

import cv2
import mss
import numpy as np

from core import capture

USER_AGENT = "DiscordBot (https://www.youtube.com/@1-vtt, 1.0)"
FOOTER = "1vtt's GPO Fishing Macro"
TIMEOUT_SEC = 15.0
JPEG_QUALITY = 85

try:
    import certifi
    _SSL = ssl.create_default_context(cafile=certifi.where())
except ImportError:
    _SSL = ssl.create_default_context()


def embed(title, color, fields, description=None):
    lines = []
    if fields:
        lines.append("  •  ".join("%s %s" % (n, v) for n, v in fields))
    if description:
        lines.append(description)
    out = {
        "title": title,
        "color": color,
        "footer": {"text": FOOTER},
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }
    if lines:
        out["description"] = "\n".join(lines)[:4096]
    return out


def _part(boundary, headers, data):
    return ("--%s\r\n%s\r\n\r\n" % (boundary, headers)).encode() + data + b"\r\n"


def body(payload, frame):
    payload = copy.deepcopy(payload)
    jpg = None
    if frame is not None:
        ok, buf = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, JPEG_QUALITY])
        if ok:
            jpg = buf.tobytes()
            if payload.get("embeds"):
                payload["embeds"][0]["image"] = {"url": "attachment://roblox.jpg"}
    boundary = uuid.uuid4().hex
    parts = [_part(boundary, 'Content-Disposition: form-data; name="payload_json"\r\nContent-Type: application/json',
                   json.dumps(payload).encode())]
    if jpg is not None:
        parts.append(_part(boundary, 'Content-Disposition: form-data; name="files[0]"; filename="roblox.jpg"\r\nContent-Type: image/jpeg', jpg))
    parts.append(("--%s--\r\n" % boundary).encode())
    return boundary, b"".join(parts)


def guard(call):
    try:
        return call()
    except urllib.error.HTTPError as exc:
        if exc.code == 429:
            return "rate limited, skipped"
        if exc.code in (401, 403, 404):
            return "the URL is wrong or the webhook was deleted"
        return "failed (HTTP %d)" % exc.code
    except (urllib.error.URLError, OSError, ValueError):
        return "failed, no connection"


def post(url, payload, frame=None):
    if not url.lower().startswith("https://"):
        return "the URL must start with https://"
    boundary, data = body(payload, frame)
    req = urllib.request.Request(url, data=data, method="POST", headers={
        "Content-Type": "multipart/form-data; boundary=%s" % boundary,
        "User-Agent": USER_AGENT,
    })

    def send():
        with urllib.request.urlopen(req, timeout=TIMEOUT_SEC, context=_SSL):
            return "sent"

    return guard(send)


def json_call(url, method, payload):
    req = urllib.request.Request(url, data=json.dumps(payload).encode(), method=method, headers={
        "Content-Type": "application/json",
        "User-Agent": USER_AGENT,
    })
    with urllib.request.urlopen(req, timeout=TIMEOUT_SEC, context=_SSL) as resp:
        raw = resp.read()
    return json.loads(raw) if raw else {}


def url_with(url, path_tail="", **query):
    parts = urllib.parse.urlsplit(url)
    q = urllib.parse.parse_qsl(parts.query) + list(query.items())
    return urllib.parse.urlunsplit(parts._replace(path=parts.path.rstrip("/") + path_tail, query=urllib.parse.urlencode(q)))


def capture_roblox():
    c = capture.roblox_client()
    if not c:
        return None
    x, y, w, h = c
    with (getattr(mss, "MSS", None) or mss.mss)() as sct:
        shot = sct.grab({"left": int(x), "top": int(y), "width": int(w), "height": int(h)})
    return np.ascontiguousarray(np.asarray(shot, dtype=np.uint8)[:, :, :3])


class Webhook(object):
    def __init__(self):
        self._busy = threading.Lock()

    def send(self, url, payload, frame, report):
        if not self._busy.acquire(blocking=False):
            return False

        def run():
            try:
                report(post(url, payload, frame))
            finally:
                self._busy.release()

        threading.Thread(target=run, daemon=True).start()
        return True


class LiveMessage(object):
    def __init__(self):
        self._lock = threading.Lock()
        self._pending = None
        self._running = False
        self._id = None
        self._url = None
        self._gen = 0

    def reset(self):
        with self._lock:
            self._gen += 1
            self._id = None
            self._url = None
            self._pending = None

    def update(self, url, payload, report):
        with self._lock:
            self._pending = (url, payload, report, self._gen)
            if self._running:
                return
            self._running = True
        threading.Thread(target=self._run, daemon=True).start()

    def _run(self):
        while True:
            with self._lock:
                job, self._pending = self._pending, None
                if job is None:
                    self._running = False
                    return
                url, payload, report, gen = job
                msg_id = self._id if self._url == url and gen == self._gen else None
            report(self._push(url, payload, msg_id, gen))

    def _push(self, url, payload, msg_id, gen):
        if not url.lower().startswith("https://"):
            return "the URL must start with https://"

        def send():
            if msg_id:
                try:
                    json_call(url_with(url, "/messages/" + msg_id), "PATCH", payload)
                    return "updated"
                except urllib.error.HTTPError as exc:
                    if exc.code != 404:
                        raise
            data = json_call(url_with(url, wait="true"), "POST", payload)
            with self._lock:
                if gen == self._gen:
                    self._id = str(data.get("id") or "") or None
                    self._url = url
            return "sent"

        return guard(send)
