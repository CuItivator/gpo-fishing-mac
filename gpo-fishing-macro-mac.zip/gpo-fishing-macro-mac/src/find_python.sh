PY=""
try_python() {
    if [ -x "$1" ] && "$1" -c 'import sys, venv; sys.exit(0 if sys.version_info >= (3, 10) else 1)' >/dev/null 2>&1; then
        PY="$1"
    fi
}
for v in 3.13 3.12 3.11 3.10; do
    [ -z "$PY" ] && try_python "/Library/Frameworks/Python.framework/Versions/$v/bin/python3"
done
for c in /opt/homebrew/bin/python3 /usr/local/bin/python3; do
    [ -z "$PY" ] && try_python "$c"
done
for n in python3.13 python3.12 python3.11 python3.10 python3; do
    if [ -z "$PY" ]; then
        c="$(command -v "$n" 2>/dev/null)"
        case "$c" in
            ""|/usr/bin/python3) ;;
            *) try_python "$c" ;;
        esac
    fi
done
if [ -z "$PY" ]; then
    echo ""
    echo "  Python was not found on this Mac."
    echo ""
    echo "  Install Python 3.12 from"
    echo "      https://www.python.org/downloads/macos/"
    echo "  then run this again."
    echo ""
    return 1
fi
return 0
