import time

import Quartz
from Quartz import (CGEventCreate, CGEventCreateKeyboardEvent, CGEventCreateMouseEvent,
                    CGEventGetLocation, CGEventPost, CGEventSetIntegerValueField,
                    CGEventSourceButtonState, CGEventSourceKeyState,
                    kCGEventLeftMouseDown, kCGEventLeftMouseDragged, kCGEventLeftMouseUp,
                    kCGEventMouseMoved, kCGEventSourceStateCombinedSessionState,
                    kCGHIDEventTap, kCGMouseButtonLeft, kCGMouseEventClickState)

_down = False
SELECT_ALL = "cmd"

KEYCODES = {"esc": 53, "escape": 53, "enter": 36, "return": 36, "tab": 48,
            "space": 49, "backspace": 51, "delete": 51, "ctrl": 59, "control": 59,
            "shift": 56, "alt": 58, "option": 58, "cmd": 55, "command": 55, "win": 55,
            "`": 50, "-": 27, "=": 24, "[": 33, "]": 30, ";": 41, "'": 39, ",": 43,
            ".": 47, "/": 44, "\\": 42,
            "0": 29, "1": 18, "2": 19, "3": 20, "4": 21, "5": 23,
            "6": 22, "7": 26, "8": 28, "9": 25, "a": 0, "b": 11, "c": 8, "d": 2,
            "e": 14, "f": 3, "g": 5, "h": 4, "i": 34, "j": 38, "k": 40, "l": 37,
            "m": 46, "n": 45, "o": 31, "p": 35, "q": 12, "r": 15, "s": 1, "t": 17,
            "u": 32, "v": 9, "w": 13, "x": 7, "y": 16, "z": 6}


def cursor_pos():
    loc = CGEventGetLocation(CGEventCreate(None))
    return [int(round(loc.x)), int(round(loc.y))]


def _post(kind, x, y):
    ev = CGEventCreateMouseEvent(None, kind, (float(x), float(y)), kCGMouseButtonLeft)
    if kind in (kCGEventLeftMouseDown, kCGEventLeftMouseUp):
        CGEventSetIntegerValueField(ev, kCGMouseEventClickState, 1)
    CGEventPost(kCGHIDEventTap, ev)


def _move_kind():
    return kCGEventLeftMouseDragged if _down else kCGEventMouseMoved


def move_to(x, y, steps=6):
    x, y = int(x), int(y)
    x0, y0 = cursor_pos()
    kind = _move_kind()
    for i in range(1, steps + 1):
        t = i / float(steps)
        _post(kind, x0 + (x - x0) * t, y0 + (y - y0) * t)
        time.sleep(0.012)
    _post(kind, x, y)
    time.sleep(0.01)


def _wiggle():
    x, y = cursor_pos()
    kind = _move_kind()
    for dx, dy in ((2, 1), (0, 0), (1, 0), (0, 0)):
        _post(kind, x + dx, y + dy)
        time.sleep(0.015)
    _post(kind, x, y)


def mouse_down():
    global _down
    x, y = cursor_pos()
    _post(kCGEventLeftMouseDown, x, y)
    _down = True


def mouse_up():
    global _down
    x, y = cursor_pos()
    _post(kCGEventLeftMouseUp, x, y)
    _down = False


def click(x, y, press=0.09):
    move_to(x, y)
    _wiggle()
    time.sleep(0.06)
    mouse_down()
    time.sleep(press)
    mouse_up()
    time.sleep(0.03)


def drag(x0, y0, x1, y1, steps=12, hold=0.15):
    move_to(x0, y0)
    _wiggle()
    time.sleep(0.08)
    mouse_down()
    time.sleep(hold)
    for i in range(1, steps + 1):
        t = i / float(steps)
        _post(kCGEventLeftMouseDragged, x0 + (x1 - x0) * t, y0 + (y1 - y0) * t)
        time.sleep(0.02)
    _post(kCGEventLeftMouseDragged, x1, y1)
    time.sleep(hold)
    mouse_up()
    time.sleep(0.05)


def _code(key):
    return KEYCODES[str(key).strip().lower()]


def key_down(key):
    CGEventPost(kCGHIDEventTap, CGEventCreateKeyboardEvent(None, _code(key), True))


def key_up(key):
    CGEventPost(kCGHIDEventTap, CGEventCreateKeyboardEvent(None, _code(key), False))


def press(key, hold=0.03):
    key_down(key)
    time.sleep(max(hold, 0.0))
    key_up(key)


def button_down():
    return bool(CGEventSourceButtonState(kCGEventSourceStateCombinedSessionState, kCGMouseButtonLeft))


def esc_down():
    return bool(CGEventSourceKeyState(kCGEventSourceStateCombinedSessionState, 53))


def _is_roblox(app):
    try:
        name = (app.localizedName() or "") + " " + (app.bundleIdentifier() or "")
    except Exception:
        return False
    return "roblox" in name.lower()


def roblox_in_front():
    try:
        from AppKit import NSWorkspace
        app = NSWorkspace.sharedWorkspace().frontmostApplication()
        return app is not None and _is_roblox(app)
    except Exception:
        return False


def focus_roblox():
    try:
        from AppKit import NSApplicationActivateIgnoringOtherApps, NSWorkspace
        if roblox_in_front():
            return True
        for app in NSWorkspace.sharedWorkspace().runningApplications():
            if _is_roblox(app):
                app.activateWithOptions_(NSApplicationActivateIgnoringOtherApps)
                time.sleep(0.3)
                return roblox_in_front()
    except Exception:
        pass
    return False


def check_permissions(log):
    where = "System Settings > Privacy & Security"
    ok = True
    try:
        if not Quartz.CGPreflightScreenCaptureAccess():
            Quartz.CGRequestScreenCaptureAccess()
            log("Screen Recording is not allowed for Terminal - turn it on under "
                "%s > Screen Recording, then start this again." % where)
            ok = False
    except Exception:
        pass
    try:
        if not Quartz.CGPreflightListenEventAccess():
            Quartz.CGRequestListenEventAccess()
            log("Input Monitoring is not allowed for Terminal - turn it on under "
                "%s > Input Monitoring, then start this again." % where)
            ok = False
    except Exception:
        pass
    try:
        from ApplicationServices import (AXIsProcessTrustedWithOptions,
                                         kAXTrustedCheckOptionPrompt)
        if not AXIsProcessTrustedWithOptions({kAXTrustedCheckOptionPrompt: True}):
            log("Accessibility is not allowed for Terminal - turn it on under "
                "%s > Accessibility, then start this again." % where)
            ok = False
    except Exception:
        pass
    return ok
