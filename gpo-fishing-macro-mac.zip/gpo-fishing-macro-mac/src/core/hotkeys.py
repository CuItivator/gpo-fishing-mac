import threading
import time

from pynput import keyboard as kb

ACTIONS = [
    ("toggle", "start / pause fishing"),
    ("cast_pos", "save the cast spot"),
    ("quit", "quit"),
]

DEFAULT_KEYS = {
    "toggle": "f1",
    "cast_pos": "f4",
    "quit": "f3",
}

MODIFIERS = {"ctrl", "shift", "alt", "cmd"}
ALIASES = {"control": "ctrl", "option": "alt", "command": "cmd", "win": "cmd",
           "windows": "cmd", "escape": "esc", "return": "enter",
           "pageup": "page_up", "pagedown": "page_down", "page up": "page_up",
           "page down": "page_down", "caps lock": "caps_lock", "del": "delete"}
NUMPAD_VK = {0: 82, 1: 83, 2: 84, 3: 85, 4: 86, 5: 87, 6: 88, 7: 89, 8: 91, 9: 92}
VK_NUMPAD = dict((v, k) for k, v in NUMPAD_VK.items())

_MOD_KEYS = {
    kb.Key.ctrl: "ctrl", kb.Key.ctrl_l: "ctrl", kb.Key.ctrl_r: "ctrl",
    kb.Key.shift: "shift", kb.Key.shift_l: "shift", kb.Key.shift_r: "shift",
    kb.Key.alt: "alt", kb.Key.alt_l: "alt", kb.Key.alt_r: "alt", kb.Key.alt_gr: "alt",
    kb.Key.cmd: "cmd", kb.Key.cmd_l: "cmd", kb.Key.cmd_r: "cmd",
}


def keys_from(cfg):
    out = dict(DEFAULT_KEYS)
    for k, v in (cfg.get("hotkeys") or {}).items():
        if k in out and isinstance(v, str) and v.strip():
            out[k] = v.strip().lower()
    return out


def numpad_digit(spec):
    parts = spec.strip().lower().split()
    if len(parts) == 2 and parts[0] == "numpad" and parts[1].isdigit():
        d = int(parts[1])
        if d in NUMPAD_VK:
            return d
    return None


def _parse(spec):
    spec = (spec or "").strip().lower()
    if not spec:
        raise ValueError("empty")
    d = numpad_digit(spec)
    if d is not None:
        return frozenset(), ("vk", NUMPAD_VK[d])
    parts = [ALIASES.get(p.strip(), p.strip()) for p in spec.split("+")]
    mods = frozenset(p for p in parts[:-1])
    if not mods <= MODIFIERS:
        raise ValueError("unknown modifier in %r" % spec)
    last = parts[-1]
    if not last:
        raise ValueError("no key in %r" % spec)
    if len(last) == 1:
        return mods, ("char", last)
    key = getattr(kb.Key, last, None)
    if key is None:
        raise ValueError("Key %r is not mapped to any known key." % last)
    return mods, ("key", key)


def valid(spec):
    try:
        _parse(spec)
    except ValueError as exc:
        return False, str(exc)
    return True, ""


def label(spec):
    d = numpad_digit(spec)
    if d is not None:
        return "Numpad %d" % d
    return "+".join(p.strip().capitalize() if len(p.strip()) > 1 else p.strip().upper()
                    for p in spec.split("+"))


class _Manager(object):
    def __init__(self):
        self.lock = threading.Lock()
        self.bindings = []
        self.held = set()
        self.pressed = set()
        self.down = set()
        self.capture = None
        self.listener = None

    def start(self):
        if self.listener is None:
            self.listener = kb.Listener(on_press=self._on_press,
                                        on_release=self._on_release)
            self.listener.daemon = True
            self.listener.start()

    def _name(self, key):
        if key in _MOD_KEYS:
            return _MOD_KEYS[key]
        vk = getattr(key, "vk", None)
        if vk in VK_NUMPAD:
            return "numpad %d" % VK_NUMPAD[vk]
        if isinstance(key, kb.Key):
            return key.name
        try:
            c = self.listener.canonical(key)
        except Exception:
            c = key
        ch = getattr(c, "char", None) or getattr(key, "char", None)
        if ch:
            return ch.lower()
        return "vk%s" % vk

    def _matches(self, target, key, name):
        kind, val = target
        if kind == "vk":
            return getattr(key, "vk", None) == val
        if kind == "key":
            return key == val
        return name == val

    def _on_press(self, key):
        name = self._name(key)
        with self.lock:
            self.pressed.add(name)
            if name in MODIFIERS:
                self.held.add(name)
                return
            if name in self.down:
                return
            self.down.add(name)
            held = frozenset(self.held)
            cap = self.capture
            hits = [cb for mods, target, cb in self.bindings
                    if mods == held and self._matches(target, key, name)]
        if cap is not None:
            cap(name, key, held)
            return
        for cb in hits:
            threading.Thread(target=cb, daemon=True).start()

    def _on_release(self, key):
        name = self._name(key)
        with self.lock:
            self.pressed.discard(name)
            self.held.discard(name)
            self.down.discard(name)

    def bind(self, spec, callback):
        mods, target = _parse(spec)
        entry = (mods, target, callback)
        with self.lock:
            self.bindings.append(entry)
        self.start()

        def remove():
            with self.lock:
                if entry in self.bindings:
                    self.bindings.remove(entry)
        return remove


_manager = _Manager()


def bind(spec, callback):
    return _manager.bind(spec, callback)


def is_pressed(name):
    _manager.start()
    name = ALIASES.get(name.strip().lower(), name.strip().lower())
    with _manager.lock:
        return name in _manager.pressed


def read_key():
    _manager.start()
    time.sleep(0.25)
    got = {}
    done = threading.Event()

    def cap(name, key, held):
        got["name"], got["held"] = name, held
        done.set()

    with _manager.lock:
        _manager.capture = cap
    try:
        done.wait()
    finally:
        with _manager.lock:
            _manager.capture = None
    name = got["name"]
    deadline = time.time() + 2.0
    while time.time() < deadline:
        with _manager.lock:
            if name not in _manager.pressed:
                break
        time.sleep(0.02)
    if name == "esc":
        return None
    if name.startswith("numpad "):
        return name
    return "+".join(sorted(got["held"]) + [name])
