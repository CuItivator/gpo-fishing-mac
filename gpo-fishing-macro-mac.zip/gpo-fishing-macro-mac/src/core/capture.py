import ctypes
import os

import mss
import numpy as np

TITLE_BAR = 28


def dpi_aware():
    if os.name != "nt":
        return
    try:
        ctypes.windll.user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
    except Exception:
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(2)
        except Exception:
            pass


def roblox_client():
    try:
        import Quartz
        opts = Quartz.kCGWindowListOptionOnScreenOnly | Quartz.kCGWindowListExcludeDesktopElements
        screen_h = Quartz.CGDisplayPixelsHigh(Quartz.CGMainDisplayID())
        for w in Quartz.CGWindowListCopyWindowInfo(opts, Quartz.kCGNullWindowID) or []:
            owner = str(w.get("kCGWindowOwnerName", "")).lower()
            if "roblox" not in owner or int(w.get("kCGWindowLayer", 0) or 0) != 0:
                continue
            b = w.get("kCGWindowBounds") or {}
            x, y = int(b.get("X", 0)), int(b.get("Y", 0))
            wd, ht = int(b.get("Width", 0)), int(b.get("Height", 0))
            if wd < 200 or ht < 200:
                continue
            bar = 0 if y <= 0 and ht >= screen_h else TITLE_BAR
            return x, y + bar, wd, ht - bar
    except Exception:
        pass
    return None


class Screen(object):
    def __init__(self):
        self.sct = (getattr(mss, "MSS", None) or mss.mss)()
        self.mon = dict(self.sct.monitors[1])
        probe = self.sct.grab(self.mon)
        self.scale = float(probe.width) / float(self.mon["width"])

    def grab(self, region=None):
        r = region or self.mon
        img = np.asarray(self.sct.grab(r))[:, :, :3]
        off = (int(round(r["left"] * self.scale)), int(round(r["top"] * self.scale)))
        return np.ascontiguousarray(img), off

    def to_points(self, v):
        return int(round(v / self.scale))

    def to_pixels(self, v):
        return int(round(v * self.scale))

    def bounds(self):
        return self.mon

    def client(self):
        c = roblox_client()
        if c:
            return c
        m = self.mon
        return m["left"], m["top"], m["width"], m["height"]
