import json
import os
import queue
import sys
import threading
import time
import tkinter as tk
import webbrowser
from tkinter import messagebox, ttk

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
CONFIG = os.path.join(ROOT, "config.json")
ASSETS = os.path.join(HERE, "assets")
sys.path.insert(0, HERE)

from core import capture, hotkeys, inputs
import area_box
import shop
from macro import Macro

AUTHOR = "1vtt"
YOUTUBE_URL = "https://www.youtube.com/@1-vtt"

BG = "#0a1b2e"
SURFACE = "#13273f"
FIELD = "#06111d"
INK = "#e6f0fa"
MUTED = "#8fa6bd"
LINE = "#2f7fb5"
ACCENT = "#2f9fd0"
ACCENT_DIM = "#1f6b94"
ACCENT_TX = "#8fd3f0"
LINK = "#bfe2f4"
KEY_FG = "#cfe6f4"
GOOD = "#7fd18b"

UI_FONT = "Segoe UI" if os.name == "nt" else "Helvetica Neue"

HOTKEY_IDS = ("toggle", "cast_pos", "quit")
HOTKEY_LABELS = {"toggle": "Start / Stop", "cast_pos": "Set cast spot", "quit": "Exit"}

DEFAULTS = {
    "hotkeys": dict(hotkeys.DEFAULT_KEYS),
    "cast_pos": None,
    "cast_wait_s": 30.0,
    "recast_delay_s": 3.0,
    "cast_delay_s": 0.25,
    "rod_key": "1",
    "auto_buy_bait": False,
    "buy_bait_every": 150,
    "auto_store": True,
    "bait": "common",
    "webhook_enabled": False,
    "webhook_url": "",
    "webhook_fail": False,
    "webhook_dc": True,
    "webhook_user": "",
    "name_read": True,
    "name_area": None,
    "shop": dict(shop.DEFAULTS),
    "advanced": {
        "lost_timeout_s": 1.5,
        "fish_hold_s": 1.0,
        "loop_hz": 30,
        "accel": 1.05,
        "latency_s": 0.10,
        "hysteresis": 0.02,
        "aim_offset": 0.0,
        "name_read_delay_s": 0.1,
    },
}

SHOP_KEYS = ("buy_when_bait_below", "max_amount")
NAME_AREA_DEFAULT = {"x": 0.4, "y": 0.3, "w": 0.2, "h": 0.06}

BAIT_CHOICES = (
    ("common", "Common Fish Bait"),
    ("rare", "Rare Fish Bait, then Common"),
    ("legendary", "Legendary Fish Bait, then Common"),
    ("best", "Best I have (Legendary > Rare > Common)"),
)

NUMBERS = {
    "cast_wait_s": (5.0, 120.0),
    "recast_delay_s": (0.0, 15.0),
    "buy_bait_every": (1.0, 10000.0),
    "buy_when_bait_below": (0.0, 10000.0),
    "max_amount": (0.0, 10000.0),
    "lost_timeout_s": (0.3, 5.0),
    "fish_hold_s": (0.2, 5.0),
    "loop_hz": (15.0, 120.0),
    "accel": (0.2, 3.0),
    "latency_s": (0.0, 0.5),
    "hysteresis": (0.0, 0.2),
    "aim_offset": (-0.5, 0.5),
    "cast_delay_s": (0.0, 2.0),
    "name_read_delay_s": (0.0, 5.0),
}

ADVANCED = (
    ("cast_delay_s", "Cast delay", "Wait after moving to the water before the click (sec)"),
    ("lost_timeout_s", "Lost timeout", "Bar gone this long = the minigame is over (sec)"),
    ("fish_hold_s", "Fish hold", "How long it keeps aiming at a fish it can't see (sec)"),
    ("loop_hz", "Scan rate", "How many times a second it reads the bar"),
    ("accel", "Zone accel", "How hard the zone is modelled to move, tune if it over/undershoots"),
    ("latency_s", "Latency", "Screen to click delay it makes up for (sec)"),
    ("hysteresis", "Dead band", "How close is close enough, lower = busier clicking"),
    ("aim_offset", "Aim offset", "Nudge the aim above (-) or below (+) the fish"),
)

HELP_TOPICS = (
    ("start", "1. Getting started", (
        "Open Grand Piece Online in the Roblox player and equip your fishing rod, stand where you can cast into the water\n\n"
        "Keep the Roblox window uncovered, the macro reads the minigame straight off the screen at any window size or zoom\n\n"
        "Press F1 to start and F1 again to stop, F3 closes the whole macro, you can change every hotkey on the Main tab"
    )),
    ("cast", "2. Cast", (
        "Press Set cast spot, then click the spot in the water where your bobber lands (or hover it and press F4), the macro clicks there to cast and recast\n\n"
        "Rod key; the number slot your rod is on (1 by default), used by the failsafe to switch it off and on if nothing bites\n\n"
        "Empty your hotbar before you start and keep only the fishing rod in slot 1, the hotbar is centred so every extra item shifts the slots around and the rod key stops matching"
    )),
    ("catch", "3. Catch", (
        "After the cast it waits for the minigame, plays it and holds click to keep the dark zone under the fish line\n\n"
        "Cast wait (default 30); how long it waits for a minigame before it resets the rod and casts again\n\n"
        "Recast delay (default 3); the pause after a catch before the next cast"
    )),
    ("bait", "4. Baits and auto-buy", (
        "Use bait; which bait it keeps selected on the Fishing Baits panel before every cast. Pick Rare or Legendary and it uses that one until it runs out, then switches to Common by itself. Best I have always takes the rarest bait you still have\n\n"
        "It reads the panel that shows while the rod is held, finds the rows by their colours (white = Common, blue = Rare, rainbow = Legendary) and clicks the row it wants when the orange border is on another one\n\n"
        "Turn on Auto-buy bait and it walks the shop dialogue (E at the sign, Yes, amount, Buy) so you never run out of Common bait\n\n"
        "Fish right next to the bait sign so pressing E opens the purchase prompt. It reads the MAX it can afford and buys that, or the Max per visit if you set one\n\n"
        "When bait below N; reads the Common bait count off the Fishing Baits panel after each catch and shops when it drops under N (0 = off, then it shops every N catches instead)\n\n"
        "Everything is found by its colours and scales with the window, half size works the same as maximised"
    )),
    ("store", "5. Auto-store items", (
        "Anything you catch that is not the rod opens a new hotbar slot. With Auto-store on, after each catch it equips the extra item and presses the green Store Fruit button\n\n"
        "If the item is still on the hotbar it opens the backpack (`), drags it from the hotbar into the inventory and closes the backpack again\n\n"
        "It then re-equips the rod (it can tell by the Fishing Baits panel) before the next cast"
    )),
    ("webhook", "6. Webhook", (
        "Comes disabled, if you're planning to afk overnight this is a decent option to have on\n\n"
        "Go to discord.com and create a private server, go to a text channel, click the settings cog next to it, Integrations, Webhooks, New Webhook, Copy Webhook URL, paste it on the Webhook tab and press Send test\n\n"
        "Long press (or right click) your username, Copy User ID and paste it in the user ID box so the alerts actually ping you, if you don't see that option turn on Developer Mode in your Discord settings\n\n"
        "Fish name; catch a fish manually and while its name is on screen click Select name area, drag the gray box over the name and press Enter, Test read shows you what it reads\n\n"
        "Send the fish name after every catch; needs only the URL and the name area, every fish you catch is read off the name area and listed as <name> x5 in one Fishing Log message that keeps updating itself, with how many were caught, how many names it could not read, the run time and the bait in use\n\n"
        "It reads the area a few times right after the catch and keeps the name it saw most, Read after is how long it waits before the first read, raise it if the name pops up late\n\n"
        "Send a screenshot after every catch; one message per catch with the catch number, the run time, the bait in use and a screenshot of the game, used when the fish name is off or no name area is set\n\n"
        "Send a screenshot after fishing fails for 60 seconds; pings you with a screenshot if nothing got caught for a whole minute\n\n"
        "Ping me every 180 seconds; pings you with a screenshot saying Possibly disconnected OR griefed every 3 minutes you go without a fish"
    )),
)


def font(size=9, weight="normal"):
    return (UI_FONT, size, weight)


def load_cfg():
    cfg = json.loads(json.dumps(DEFAULTS))
    if os.path.exists(CONFIG):
        try:
            with open(CONFIG, "r", encoding="utf-8") as f:
                raw = json.load(f)
        except (OSError, ValueError):
            raw = {}
        if isinstance(raw, dict):
            for k, v in raw.items():
                if isinstance(v, dict) and isinstance(cfg.get(k), dict):
                    cfg[k].update(v)
                else:
                    cfg[k] = v
    else:
        save_cfg(cfg)
    return cfg


def save_cfg(cfg):
    try:
        with open(CONFIG, "w", encoding="utf-8") as f:
            json.dump(cfg, f, indent=2)
    except OSError:
        pass


LOG = os.path.join(ROOT, "macro.log")
_last_logged = [None]


def log_line(text):
    if text == _last_logged[0]:
        return
    _last_logged[0] = text
    try:
        if os.path.exists(LOG) and os.path.getsize(LOG) > 2_000_000:
            os.remove(LOG)
        with open(LOG, "a", encoding="utf-8") as f:
            f.write("%s  %s\n" % (time.strftime("%H:%M:%S"), text))
    except OSError:
        pass


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("1vtt's GPO Fishing Macro")
        self.minsize(400, 540)
        self.geometry("420x620")
        self.configure(bg=BG)
        self._images = {}
        for name in ("app.png", "fish.png"):
            try:
                self._images[name] = tk.PhotoImage(file=os.path.join(ASSETS, name))
            except tk.TclError:
                pass
        try:
            self.iconbitmap(default=os.path.join(ASSETS, "app.ico"))
        except tk.TclError:
            if "app.png" in self._images:
                self.iconphoto(True, self._images["app.png"])

        self.cfg = load_cfg()
        log_line("---- macro started")
        self.macro = Macro(self.cfg, self._set_status, lambda: save_cfg(self.cfg))
        self._status_text = "Ready - hover the water, press %s, then %s to fish" % (
            hotkeys.label(self.cfg["hotkeys"]["cast_pos"]), hotkeys.label(self.cfg["hotkeys"]["toggle"]))
        self._status = tk.StringVar(value=self._status_text)
        self._closing = False
        self._was_running = False
        self._removers = {}
        self._listening = None
        self._events = queue.Queue()
        self._hotkey_vars = {}
        self._hotkey_btns = {}
        self._cast_label = tk.StringVar()

        self._number_vars = {k: tk.StringVar(value=self._fmt(self._cfg_get(k))) for k in NUMBERS}
        for k, var in self._number_vars.items():
            var.trace_add("write", lambda *_a, key=k: self._on_number(key))
        self.rod_key = tk.StringVar(value=str(self.cfg["rod_key"]))
        self.rod_key.trace_add("write", lambda *_: self._on_rod_key())
        self.auto_bait = tk.BooleanVar(value=bool(self.cfg["auto_buy_bait"]))
        self.auto_store = tk.BooleanVar(value=bool(self.cfg.get("auto_store", True)))
        self.bait_pick = tk.StringVar(value=dict(BAIT_CHOICES).get(self.cfg.get("bait", "common"), BAIT_CHOICES[0][1]))
        self.bait_pick.trace_add("write", lambda *_: self._on_bait_pick())
        self.webhook_enabled = tk.BooleanVar(value=bool(self.cfg["webhook_enabled"]))
        self.webhook_fail = tk.BooleanVar(value=bool(self.cfg["webhook_fail"]))
        self.webhook_dc = tk.BooleanVar(value=bool(self.cfg["webhook_dc"]))
        self.webhook_url = tk.StringVar(value=str(self.cfg["webhook_url"]))
        self.webhook_user = tk.StringVar(value=str(self.cfg["webhook_user"]))
        for var in (self.webhook_enabled, self.webhook_fail, self.webhook_dc, self.webhook_url, self.webhook_user):
            var.trace_add("write", lambda *_: self._on_webhook_change())
        self.name_read = tk.BooleanVar(value=bool(self.cfg.get("name_read", True)))
        self._name_area_label = tk.StringVar()
        self._area_box = None
        self._area_bounds = None
        self._countdown = None

        self._build_ui()
        self._refresh_cast_label()
        self._bind_all_hotkeys()
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        self._check_permissions()
        self._tick()

    @staticmethod
    def _fmt(value):
        return ("%.4f" % float(value)).rstrip("0").rstrip(".")

    def _cfg_get(self, key):
        if key in SHOP_KEYS:
            return self.cfg["shop"].get(key, shop.DEFAULTS[key])
        return self.cfg["advanced"][key] if key in self.cfg["advanced"] else self.cfg[key]

    def _cfg_set(self, key, value):
        if key in SHOP_KEYS:
            self.cfg["shop"][key] = value
        elif key in self.cfg["advanced"]:
            self.cfg["advanced"][key] = value
        else:
            self.cfg[key] = value

    def _check_permissions(self):
        try:
            inputs.check_permissions(self._set_status)
        except Exception:
            pass

    def _style(self):
        s = ttk.Style(self)
        s.theme_use("clam")
        s.configure(".", background=BG, foreground=INK, fieldbackground=FIELD, font=font(9))
        s.configure("TFrame", background=BG)
        s.configure("TLabel", background=BG, foreground=INK)
        s.configure("Muted.TLabel", foreground=MUTED)
        s.configure("Live.TLabel", foreground=ACCENT_TX, font=font(9, "bold"))
        s.configure("Key.TLabel", background=FIELD, foreground=KEY_FG, font=font(9, "bold"), anchor="center", padding=(6, 2))
        s.configure("TLabelframe", background=BG, bordercolor=LINE, lightcolor=LINE, darkcolor=LINE, relief="solid", borderwidth=1)
        s.configure("TLabelframe.Label", background=BG, foreground=ACCENT_TX, font=font(9, "bold"))
        s.configure("TCheckbutton", background=BG, foreground=INK)
        s.map("TCheckbutton", background=[("active", BG)], indicatorcolor=[("selected", ACCENT), ("!selected", FIELD)])
        s.configure("TRadiobutton", background=BG, foreground=INK)
        s.map("TRadiobutton", background=[("active", BG)], indicatorcolor=[("selected", ACCENT), ("!selected", FIELD)])
        s.configure("TButton", background=SURFACE, foreground=INK, bordercolor=LINE, padding=(8, 2))
        s.map("TButton", background=[("active", ACCENT), ("pressed", ACCENT_DIM)], foreground=[("active", "#ffffff")])
        s.configure("Big.TButton", font=font(14, "bold"), padding=(10, 8), background=SURFACE, foreground=ACCENT,
                    bordercolor=ACCENT, lightcolor=ACCENT, darkcolor=ACCENT)
        s.map("Big.TButton", background=[("active", ACCENT), ("pressed", ACCENT_DIM)], foreground=[("active", "#ffffff")])
        s.configure("Toolbutton", background=SURFACE, foreground=INK, bordercolor=LINE, padding=(8, 4), anchor="center")
        s.map("Toolbutton", background=[("selected", ACCENT_DIM), ("active", ACCENT)], foreground=[("active", "#ffffff"), ("selected", INK)])
        s.configure("TEntry", fieldbackground=FIELD, foreground=INK, insertcolor=INK, bordercolor=LINE)
        s.configure("TNotebook", background=BG, bordercolor=LINE, tabmargins=(2, 4, 2, 0))
        s.configure("TNotebook.Tab", background=SURFACE, foreground=INK, padding=(6, 3))
        s.map("TNotebook.Tab", background=[("selected", ACCENT_DIM)], foreground=[("disabled", MUTED), ("selected", "#ffffff")])
        s.configure("Vertical.TScrollbar", background=SURFACE, troughcolor=BG, bordercolor=LINE, arrowcolor=INK)

    def _link(self, parent, text, url):
        lbl = ttk.Label(parent, text=text, foreground=LINK, cursor="hand2")
        lbl.bind("<Button-1>", lambda _e, u=url: webbrowser.open(u))
        return lbl

    def _number_entry(self, parent, key, width=6):
        entry = ttk.Entry(parent, textvariable=self._number_vars[key], width=width)
        entry.bind("<FocusOut>", lambda _e, k=key: self._tidy_number(k))
        return entry

    def _build_ui(self):
        self._style()
        self.columnconfigure(0, weight=1)
        self.rowconfigure(2, weight=1)

        top = ttk.Frame(self, padding=(8, 8, 8, 4))
        top.grid(row=0, column=0, sticky="ew")
        top.columnconfigure(0, weight=1)
        self._start_btn = ttk.Button(top, text=self._start_text(), style="Big.TButton", command=self._toggle)
        self._start_btn.grid(row=0, column=0, columnspan=2, sticky="ew")
        ttk.Label(top, text="by %s" % AUTHOR, style="Muted.TLabel").grid(row=1, column=0, sticky="w", pady=(4, 0))
        self._link(top, "youtube.com/@1-vtt", YOUTUBE_URL).grid(row=1, column=1, sticky="e", pady=(4, 0))

        live = ttk.LabelFrame(self, text="Live", padding=(8, 4))
        live.grid(row=1, column=0, sticky="ew", padx=8, pady=(2, 0))
        live.columnconfigure(1, weight=1)
        self._dot = tk.Canvas(live, width=12, height=12, bg=BG, highlightthickness=0)
        self._dot.grid(row=0, column=0, sticky="w", padx=(0, 6))
        self._dot_id = self._dot.create_oval(1, 1, 11, 11, fill=MUTED, outline="")
        self._state_var = tk.StringVar(value="Stopped")
        ttk.Label(live, textvariable=self._state_var, style="Live.TLabel").grid(row=0, column=1, sticky="w")
        self._catch_var = tk.StringVar(value="0 caught")
        ttk.Label(live, textvariable=self._catch_var, style="Muted.TLabel").grid(row=0, column=2, sticky="e")

        self._tabs = ttk.Notebook(self)
        self._tabs.grid(row=2, column=0, sticky="nsew", padx=8, pady=4)
        main_tab = ttk.Frame(self._tabs)
        help_tab = ttk.Frame(self._tabs)
        adv_tab = ttk.Frame(self._tabs)
        hook_tab = ttk.Frame(self._tabs)
        self._tabs.add(main_tab, text="Main")
        self._tabs.add(help_tab, text="How to Use")
        self._tabs.add(adv_tab, text="Advanced")
        self._tabs.add(hook_tab, text="Webhook")
        self._build_main_tab(main_tab)
        self._build_help_tab(help_tab)
        self._build_advanced_tab(adv_tab)
        self._build_webhook_tab(hook_tab)

        foot = ttk.Frame(self, padding=(8, 2, 8, 6))
        foot.grid(row=3, column=0, sticky="ew")
        if "fish.png" in self._images:
            ttk.Label(foot, image=self._images["fish.png"]).pack(side="left", padx=(0, 6))
        ttk.Label(foot, textvariable=self._status, style="Muted.TLabel", wraplength=350, anchor="w").pack(side="left", fill="x", expand=True)

    def _scrollable(self, parent, row):
        parent.columnconfigure(0, weight=1)
        parent.rowconfigure(row, weight=1)
        canvas = tk.Canvas(parent, bg=BG, highlightthickness=0, bd=0)
        bar = ttk.Scrollbar(parent, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=bar.set)
        canvas.grid(row=row, column=0, sticky="nsew", padx=(6, 0), pady=6)
        bar.grid(row=row, column=1, sticky="ns", pady=6)
        inner = ttk.Frame(canvas)
        win_id = canvas.create_window((0, 0), window=inner, anchor="nw")
        inner.bind("<Configure>", lambda _e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda e: canvas.itemconfigure(win_id, width=e.width))

        def wheel(e):
            if not canvas.winfo_exists():
                return
            step = -1 if (getattr(e, "num", 0) == 4 or e.delta > 0) else 1
            canvas.yview_scroll(step, "units")

        canvas.bind("<Enter>", lambda _e: canvas.bind_all("<MouseWheel>", wheel))
        canvas.bind("<Leave>", lambda _e: canvas.unbind_all("<MouseWheel>"))
        return inner

    def _build_main_tab(self, outer):
        parent = self._scrollable(outer, 0)
        parent.columnconfigure(0, weight=1)
        parent.columnconfigure(1, weight=1)

        hk = ttk.LabelFrame(parent, text="Hotkeys", padding=6)
        hk.grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 6))
        hk.columnconfigure(1, weight=1)
        for r, kid in enumerate(HOTKEY_IDS):
            ttk.Label(hk, text=HOTKEY_LABELS[kid]).grid(row=r, column=0, sticky="w", padx=(0, 8), pady=1)
            var = tk.StringVar(value=hotkeys.label(self.cfg["hotkeys"][kid]))
            self._hotkey_vars[kid] = var
            ttk.Label(hk, textvariable=var, style="Key.TLabel", width=10).grid(row=r, column=1, sticky="w", pady=1)
            btn = ttk.Button(hk, text="Change", width=11, command=lambda k=kid: self._start_listen(k))
            btn.grid(row=r, column=2, sticky="e", pady=1)
            self._hotkey_btns[kid] = btn

        cast = ttk.LabelFrame(parent, text="1. Cast", padding=6)
        cast.grid(row=1, column=0, sticky="nsew", padx=(0, 3), pady=(0, 6))
        ttk.Button(cast, text="Set cast spot", command=self._arm_cast_click).grid(row=0, column=0, columnspan=2, sticky="w")
        ttk.Label(cast, textvariable=self._cast_label, style="Muted.TLabel").grid(row=1, column=0, columnspan=2, sticky="w")
        ttk.Label(cast, text="Rod key").grid(row=2, column=0, sticky="w", pady=(6, 0))
        ttk.Entry(cast, textvariable=self.rod_key, width=4).grid(row=2, column=1, sticky="w", padx=4, pady=(6, 0))
        ttk.Label(cast, text="Click the button, then click the water in Roblox. Or hover the water and press the hotkey",
                  style="Muted.TLabel", wraplength=170, justify="left").grid(row=3, column=0, columnspan=2, sticky="w", pady=(4, 0))

        catch = ttk.LabelFrame(parent, text="2. Catch", padding=6)
        catch.grid(row=1, column=1, sticky="nsew", padx=(3, 0), pady=(0, 6))
        ttk.Label(catch, text="Cast wait (sec)").grid(row=0, column=0, sticky="w")
        self._number_entry(catch, "cast_wait_s").grid(row=0, column=1, sticky="w", padx=4)
        ttk.Label(catch, text="Recast delay (sec)").grid(row=1, column=0, sticky="w", pady=(2, 0))
        self._number_entry(catch, "recast_delay_s").grid(row=1, column=1, sticky="w", padx=4, pady=(2, 0))
        ttk.Label(catch, text="No minigame in time = resets the rod and casts again",
                  style="Muted.TLabel", wraplength=170, justify="left").grid(row=2, column=0, columnspan=2, sticky="w", pady=(4, 0))

        bait = ttk.LabelFrame(parent, text="3. Baits", padding=6)
        bait.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(0, 6))
        bait.columnconfigure(2, weight=1)
        ttk.Label(bait, text="Use bait").grid(row=0, column=0, sticky="w")
        ttk.Combobox(bait, textvariable=self.bait_pick, values=[label for _k, label in BAIT_CHOICES], state="readonly",
                     width=34).grid(row=0, column=1, columnspan=3, sticky="w", padx=(12, 0))
        ttk.Label(bait, text="Keeps that bait selected on the Fishing Baits panel until it runs out, then falls back to Common.",
                  style="Muted.TLabel", wraplength=360, justify="left").grid(row=1, column=0, columnspan=4, sticky="w", pady=(4, 6))
        ttk.Checkbutton(bait, text="Auto-buy bait", variable=self.auto_bait, command=self._on_bait_toggle).grid(row=2, column=0, sticky="w")
        ttk.Label(bait, text="Every").grid(row=2, column=1, sticky="e", padx=(12, 2))
        self._number_entry(bait, "buy_bait_every", width=6).grid(row=2, column=2, sticky="w")
        ttk.Label(bait, text="catches").grid(row=2, column=3, sticky="w", padx=(2, 0))
        ttk.Label(bait, text="or when Common below").grid(row=3, column=0, sticky="w", pady=(2, 0))
        self._number_entry(bait, "buy_when_bait_below", width=6).grid(row=3, column=2, sticky="w", pady=(2, 0))
        ttk.Label(bait, text="(0 = off)").grid(row=3, column=3, sticky="w", padx=(2, 0), pady=(2, 0))
        ttk.Label(bait, text="Max per visit").grid(row=4, column=0, sticky="w", pady=(2, 0))
        self._number_entry(bait, "max_amount", width=6).grid(row=4, column=2, sticky="w", pady=(2, 0))
        ttk.Label(bait, text="(0 = MAX)").grid(row=4, column=3, sticky="w", padx=(2, 0), pady=(2, 0))
        ttk.Label(bait, text="Fish next to the bait sign so E opens the shop. It reads the Common bait count off the Fishing Baits panel and the MAX it can afford.",
                  style="Muted.TLabel", wraplength=360, justify="left").grid(row=5, column=0, columnspan=4, sticky="w", pady=(4, 0))

        store = ttk.LabelFrame(parent, text="4. Auto-store items", padding=6)
        store.grid(row=3, column=0, columnspan=2, sticky="ew", pady=(0, 6))
        ttk.Checkbutton(store, text="Auto-store items", variable=self.auto_store, command=self._on_store_toggle).grid(row=0, column=0, sticky="w")
        ttk.Label(store, text="Any extra hotbar slot after a catch: equip it, Store Fruit, otherwise drag it into the backpack, then re-equip the rod.",
                  style="Muted.TLabel", wraplength=360, justify="left").grid(row=1, column=0, sticky="w", pady=(4, 0))

    def _build_webhook_tab(self, parent):
        inner = self._scrollable(parent, 0)
        box = ttk.LabelFrame(inner, text="Discord webhook", padding=8)
        box.pack(fill="x", padx=(0, 4), pady=(0, 6))
        box.columnconfigure(0, weight=1)
        ttk.Label(box, text="Webhook URL").grid(row=0, column=0, sticky="w", pady=(0, 2))
        ttk.Entry(box, textvariable=self.webhook_url).grid(row=1, column=0, sticky="ew")
        ttk.Label(box, text="Your Discord user ID (pinged by the alerts)").grid(row=2, column=0, sticky="w", pady=(8, 2))
        ttk.Entry(box, textvariable=self.webhook_user, width=24).grid(row=3, column=0, sticky="w")
        ttk.Button(box, text="Send test", command=self.macro.test_webhook).grid(row=4, column=0, sticky="w", pady=(8, 0))

        fish = ttk.LabelFrame(inner, text="Fish name", padding=8)
        fish.pack(fill="x", padx=(0, 4), pady=(0, 6))
        fish.columnconfigure(1, weight=1)
        ttk.Checkbutton(fish, text='Send the fish name after every catch ("<name> x5" Fishing Log)', variable=self.name_read,
                        command=self._on_name_read_toggle).grid(row=0, column=0, columnspan=2, sticky="w")
        ttk.Button(fish, text="Select name area", command=self._select_name_area).grid(row=1, column=0, sticky="w", pady=(6, 0))
        ttk.Label(fish, textvariable=self._name_area_label, style="Muted.TLabel").grid(row=1, column=1, sticky="w", padx=6, pady=(6, 0))
        ttk.Button(fish, text="Test read", command=self.macro.test_name_read).grid(row=2, column=0, sticky="w", pady=(6, 0))
        read_after = ttk.Frame(fish)
        read_after.grid(row=2, column=1, sticky="w", padx=6, pady=(6, 0))
        ttk.Label(read_after, text="Read after (sec)").pack(side="left")
        self._number_entry(read_after, "name_read_delay_s", width=6).pack(side="left", padx=(6, 0))
        ttk.Label(fish, text="Catch a fish by hand and while its name is on screen click Select name area, drag the gray box over the name and press Enter, "
                             "then Test read. Every catch is then read off that box and listed by name in one Fishing Log message that keeps updating itself.",
                  style="Muted.TLabel", wraplength=360, justify="left").grid(row=3, column=0, columnspan=2, sticky="w", pady=(6, 0))
        self._refresh_name_area_label()

        alerts = ttk.LabelFrame(inner, text="Screenshots and alerts", padding=8)
        alerts.pack(fill="x", padx=(0, 4), pady=(0, 6))
        alerts.columnconfigure(0, weight=1)
        ttk.Checkbutton(alerts, text="Send a screenshot after every catch (when the fish name is not read)",
                        variable=self.webhook_enabled).grid(row=0, column=0, sticky="w")
        ttk.Checkbutton(alerts, text="Send a screenshot after fishing fails for 60 seconds", variable=self.webhook_fail).grid(row=1, column=0, sticky="w", pady=(2, 0))
        ttk.Checkbutton(alerts, text='Ping me every 180 seconds with no fish caught ("Possibly disconnected OR griefed")',
                        variable=self.webhook_dc).grid(row=2, column=0, sticky="w", pady=(2, 0))
        ttk.Label(alerts, text="Catch screenshots carry the catch number, the run time and the bait in use. With the fish name on, the Fishing Log replaces them.",
                  style="Muted.TLabel", wraplength=360, justify="left").grid(row=3, column=0, sticky="w", pady=(6, 0))

    def _refresh_name_area_label(self):
        area = self.cfg.get("name_area")
        if not area:
            self._name_area_label.set("Not set")
        else:
            self._name_area_label.set("Set (%d%% x %d%% of Roblox)" % (round(area["w"] * 100), round(area["h"] * 100)))

    def _on_name_read_toggle(self):
        self.cfg["name_read"] = bool(self.name_read.get())
        self._persist()
        if not self.cfg["name_read"]:
            return
        if not self.cfg.get("name_area"):
            self._set_status("Now select the name area (Webhook > Select name area).")
        self.macro.warm_names()

    def _select_name_area(self):
        if self.macro.running:
            self._set_status("Stop first, then select the name area.")
            return
        if self._area_box is not None:
            return
        bounds = capture.roblox_client()
        if not bounds:
            self._set_status("Open Roblox first, the name area is saved inside the Roblox window.")
            return
        self._area_bounds = bounds
        rect = area_box.to_pixels(self.cfg.get("name_area") or NAME_AREA_DEFAULT, bounds)
        self._set_status("Drag the box over the fish name. Enter saves, Esc cancels.")
        self._area_box = area_box.AreaBox(self, rect, bounds, self._on_name_area_saved, self._on_name_area_cancelled)

    def _on_name_area_saved(self, rect):
        self._area_box = None
        self.cfg["name_area"] = area_box.to_fractions(rect, self._area_bounds)
        self._persist()
        self._refresh_name_area_label()
        self._set_status("Name area saved. Press Test read while a fish name is on screen.")
        self.macro.warm_names()

    def _on_name_area_cancelled(self):
        self._area_box = None
        self._set_status("Name area not changed.")

    def _on_webhook_change(self):
        self.cfg["webhook_enabled"] = bool(self.webhook_enabled.get())
        self.cfg["webhook_fail"] = bool(self.webhook_fail.get())
        self.cfg["webhook_dc"] = bool(self.webhook_dc.get())
        self.cfg["webhook_url"] = self.webhook_url.get().strip()
        self.cfg["webhook_user"] = "".join(ch for ch in self.webhook_user.get() if ch.isdigit())[:20]
        self._persist()

    def _build_help_tab(self, parent):
        self._help_topic = tk.StringVar(value=HELP_TOPICS[0][0])
        picks = ttk.Frame(parent, padding=(6, 6, 6, 0))
        picks.grid(row=0, column=0, sticky="ew")
        picks.columnconfigure(0, weight=1)
        picks.columnconfigure(1, weight=1)
        for i, (key, title, _t) in enumerate(HELP_TOPICS):
            ttk.Radiobutton(picks, text=title, value=key, variable=self._help_topic, style="Toolbutton",
                            command=self._show_help).grid(row=i // 2, column=i % 2, sticky="ew", padx=2, pady=2)
        inner = self._scrollable(parent, 1)
        self._help_box = ttk.LabelFrame(inner, padding=8)
        self._help_box.pack(fill="x", padx=(0, 4))
        self._help_text = ttk.Label(self._help_box, wraplength=340, justify="left")
        self._help_text.pack(anchor="w")
        self._show_help()

    def _show_help(self):
        for key, title, text in HELP_TOPICS:
            if key == self._help_topic.get():
                self._help_box.configure(text=title)
                self._help_text.configure(text=text)

    def _build_advanced_tab(self, parent):
        parent.columnconfigure(0, weight=1)
        parent.rowconfigure(1, weight=1)
        head = ttk.Frame(parent, padding=(6, 6, 6, 0))
        head.grid(row=0, column=0, sticky="ew")
        head.columnconfigure(0, weight=1)
        ttk.Label(head, text="Saves as you type, Reset defaults fixes anything you mess up",
                  style="Muted.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Button(head, text="Reset defaults", command=self._reset_advanced).grid(row=0, column=1, sticky="e")
        inner = self._scrollable(parent, 1)
        box = ttk.LabelFrame(inner, text="Minigame", padding=6)
        box.pack(fill="x", pady=(0, 6), padx=(0, 4))
        box.columnconfigure(2, weight=1)
        for r, (key, label, help_text) in enumerate(ADVANCED):
            ttk.Label(box, text=label).grid(row=r, column=0, sticky="w", pady=1)
            self._number_entry(box, key, width=7).grid(row=r, column=1, sticky="w", padx=6)
            ttk.Label(box, text=help_text, style="Muted.TLabel", wraplength=200, justify="left").grid(row=r, column=2, sticky="w")

    def _set_status(self, text):
        self._status_text = text
        log_line(text)

    def _persist(self):
        save_cfg(self.cfg)

    def _on_number(self, key):
        try:
            value = float(self._number_vars[key].get())
        except ValueError:
            return
        lo, hi = NUMBERS[key]
        value = min(hi, max(lo, value))
        if key in ("loop_hz", "buy_bait_every", "buy_when_bait_below", "max_amount"):
            value = int(round(value))
        self._cfg_set(key, value)
        self._persist()

    def _tidy_number(self, key):
        var = self._number_vars[key]
        try:
            value = float(var.get())
        except ValueError:
            var.set(self._fmt(self._cfg_get(key)))
            return
        lo, hi = NUMBERS[key]
        if not lo <= value <= hi:
            var.set(self._fmt(self._cfg_get(key)))

    def _reset_advanced(self):
        for key, _l, _h in ADVANCED:
            default = DEFAULTS["advanced"].get(key, DEFAULTS.get(key))
            self._number_vars[key].set(self._fmt(default))
        self._set_status("Advanced settings reset to defaults.")

    def _on_rod_key(self):
        text = self.rod_key.get().strip()
        if len(text) > 1:
            self.rod_key.set(text[-1])
            return
        self.cfg["rod_key"] = text or DEFAULTS["rod_key"]
        self._persist()

    def _on_bait_toggle(self):
        self.cfg["auto_buy_bait"] = bool(self.auto_bait.get())
        self._persist()

    def _on_bait_pick(self):
        label = self.bait_pick.get()
        for key, text in BAIT_CHOICES:
            if text == label:
                self.cfg["bait"] = key
                self._persist()
                return

    def _on_store_toggle(self):
        self.cfg["auto_store"] = bool(self.auto_store.get())
        self._persist()

    def _arm_cast_click(self):
        if self.macro.running:
            self._set_status("Stop the macro before setting the cast spot.")
            return
        if self._countdown:
            return
        self._countdown = True
        self._set_status("Now click the water in Roblox (Esc cancels)...")
        threading.Thread(target=self._cast_click_thread, daemon=True).start()

    def _cast_click_thread(self):
        deadline = time.time() + 30.0
        while inputs.button_down():
            time.sleep(0.02)
        pos = None
        while time.time() < deadline:
            if inputs.esc_down():
                break
            if inputs.button_down():
                pos = inputs.cursor_pos()
                break
            time.sleep(0.01)
        self._events.put(("cast_click", pos))

    def _apply_cast_click(self, pos):
        self._countdown = None
        if pos is None:
            self._set_status("Cast spot not changed.")
            return
        if self._inside_me(*pos):
            self._set_status("That click was on the macro window - press the button again and click the water in Roblox.")
            return
        self.cfg["cast_pos"] = [int(pos[0]), int(pos[1])]
        self._persist()
        self._refresh_cast_label()
        self._set_status("Cast spot saved at %d, %d." % tuple(self.cfg["cast_pos"]))

    def _inside_me(self, x, y):
        try:
            x0, y0 = self.winfo_rootx(), self.winfo_rooty()
            return x0 <= x <= x0 + self.winfo_width() and y0 <= y <= y0 + self.winfo_height()
        except tk.TclError:
            return False

    def _refresh_cast_label(self):
        pos = self.cfg.get("cast_pos")
        self._cast_label.set("Spot: %d, %d" % (pos[0], pos[1]) if pos else "Spot: not set yet")

    def _start_text(self):
        key = hotkeys.label(self.cfg["hotkeys"]["toggle"])
        return "Press To Stop (%s)" % key if self.macro.running else "Press To Start (%s)" % key

    def _toggle(self):
        if self.macro.running:
            self.macro.stop()
            self._set_status("Stopped. Press %s to fish again." % hotkeys.label(self.cfg["hotkeys"]["toggle"]))
        else:
            if not self.macro.has_cast():
                self._set_status("Set the cast spot first - hover the water and press %s." % hotkeys.label(self.cfg["hotkeys"]["cast_pos"]))
                return
            self._set_status("Starting - click into Roblox.")
            self.macro.start()
        self._start_btn.configure(text=self._start_text())

    def _bind_all_hotkeys(self):
        actions = {"toggle": self._hk_toggle, "cast_pos": self._hk_cast, "quit": self._hk_quit}
        for kid in HOTKEY_IDS:
            self._rebind(kid, actions[kid])

    def _unbind_all(self):
        for kid in list(self._removers):
            rem = self._removers.pop(kid, None)
            if rem:
                try:
                    rem()
                except Exception:
                    pass

    def _rebind(self, kid, callback):
        old = self._removers.pop(kid, None)
        if old:
            try:
                old()
            except Exception:
                pass
        spec = self.cfg["hotkeys"].get(kid)
        if not spec:
            return
        ok, _why = hotkeys.valid(spec)
        if not ok:
            return
        try:
            self._removers[kid] = hotkeys.bind(spec, callback)
        except Exception:
            pass

    def _hk_toggle(self):
        self._events.put(("toggle", None))

    def _hk_cast(self):
        x, y = inputs.cursor_pos()
        if self._inside_me(x, y):
            self._set_status("That spot is on the macro window - hover the water in Roblox and press the hotkey there.")
            return
        self.macro.set_cast()
        self._events.put(("cast_done", None))

    def _hk_quit(self):
        self._events.put(("quit", None))

    def _start_listen(self, kid):
        if self._listening is not None:
            return
        self._listening = kid
        self._unbind_all()
        self._hotkey_btns[kid].configure(text="Press a key")
        self._set_status("Press a key for %s (Esc cancels)" % HOTKEY_LABELS[kid])
        threading.Thread(target=self._listen_thread, args=(kid,), daemon=True).start()

    def _listen_thread(self, kid):
        try:
            spec = hotkeys.read_key()
        except Exception:
            spec = None
        self._events.put(("rebind", (kid, spec)))

    def _apply_rebind(self, kid, spec):
        self._hotkey_btns[kid].configure(text="Change")
        self._listening = None
        ok, why = hotkeys.valid(spec) if spec is not None else (False, "")
        clash = next((o for o in HOTKEY_IDS if o != kid and self.cfg["hotkeys"].get(o) == spec), None)
        if spec is None:
            self._set_status("Hotkey change cancelled.")
        elif not ok:
            self._set_status("Can't use that key: %s" % why)
        elif clash is not None:
            messagebox.showwarning("Hotkey in use",
                                   '"%s" is already set to %s.' % (hotkeys.label(spec), HOTKEY_LABELS[clash]), parent=self)
        else:
            self.cfg["hotkeys"][kid] = spec
            self._hotkey_vars[kid].set(hotkeys.label(spec))
            self._persist()
            self._start_btn.configure(text=self._start_text())
            self._set_status("%s set to %s." % (HOTKEY_LABELS[kid], hotkeys.label(spec)))
        self._bind_all_hotkeys()

    def _drain_events(self):
        while True:
            try:
                kind, data = self._events.get_nowait()
            except queue.Empty:
                break
            if kind == "toggle":
                self._toggle()
            elif kind == "cast_done":
                self._refresh_cast_label()
            elif kind == "cast_click":
                self._apply_cast_click(data)
            elif kind == "quit":
                self._on_close()
                return
            elif kind == "rebind":
                self._apply_rebind(*data)

    def _refresh_status(self):
        running = self.macro.running
        if running != self._was_running:
            self._was_running = running
            self._start_btn.configure(text=self._start_text())
        self._state_var.set({"idle": "Stopped", "casting": "Casting", "waiting": "Waiting",
                             "playing": "Playing", "buying bait": "Buying bait", "storing": "Storing"}.get(self.macro.state, "Running")
                            if running or self.macro.state != "idle" else "Stopped")
        self._dot.itemconfigure(self._dot_id, fill=GOOD if running else MUTED)
        extra = ""
        if self.macro.bait_name is not None:
            extra = "  ·  " + self.macro.bait_name + ("" if self.macro.bait is None else " x%d" % self.macro.bait)
        if self.macro.last_fish and not self.macro.last_fish.startswith("name not read"):
            extra += "  ·  last: " + self.macro.last_fish
        self._catch_var.set("%d caught" % self.macro.catches + extra)
        if self._listening is None and self._status.get() != self._status_text:
            self._status.set(self._status_text)

    def _tick(self):
        if self._closing:
            return
        self._drain_events()
        if self._closing:
            return
        self._refresh_status()
        self.after(60, self._tick)

    def _on_close(self):
        if self._closing:
            return
        self._closing = True
        for rem in self._removers.values():
            try:
                rem()
            except Exception:
                pass
        self.macro.close()
        self._persist()
        self.destroy()


def main():
    if "--check" in sys.argv:
        return 0
    capture.dpi_aware()
    App().mainloop()
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        try:
            inputs.mouse_up()
        except Exception:
            pass
        sys.exit(0)
