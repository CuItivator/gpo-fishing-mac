#!/bin/bash
cd "$(dirname "$0")"
source src/find_python.sh || { read -n 1 -s -r -p "  press any key to close"; exit 1; }
"$PY" src/bootstrap.py main.py --check
rc=$?
echo ""
if [ $rc -ne 0 ]; then
    echo "  Setup did not finish - see the messages above and setup-log.txt."
else
    echo "  Setup finished. Start the macro with Launch.command."
fi
echo ""
read -n 1 -s -r -p "  press any key to close"
